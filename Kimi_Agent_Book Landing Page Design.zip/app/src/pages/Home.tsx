import { useEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import Hero from '../sections/Hero';
import OdometerSection from '../sections/OdometerSection';
import StackingCards from '../sections/StackingCards';
import Footer from '../sections/Footer';

gsap.registerPlugin(ScrollTrigger);

export default function Home() {
  useEffect(() => {
    // Refresh ScrollTrigger after all content is loaded
    ScrollTrigger.refresh();

    return () => {
      ScrollTrigger.getAll().forEach(st => st.kill());
    };
  }, []);

  return (
    <main className="relative w-full overflow-x-hidden" style={{ backgroundColor: '#050505' }}>
      <Hero />
      <OdometerSection />
      <StackingCards />
      <Footer />
    </main>
  );
}
