import { useRef, useMemo, useEffect, useState } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const DIGIT_HEIGHT = 2;
const DIGIT_WIDTH = 1.5;
const DIGIT_DEPTH = 1.5;
const DIGIT_COUNT = 5;
const SPACING = 0.2;

function createDigitTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 5120; // 10 digits * 512px each
  const ctx = canvas.getContext('2d')!;

  // Fill background
  ctx.fillStyle = '#D91D1D'; // Votive Red
  ctx.fillRect(0, 0, 512, 5120);

  // Draw digits
  ctx.fillStyle = '#050505'; // Deep Black
  ctx.font = 'bold 420px "EB Garamond", serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';

  for (let i = 0; i < 10; i++) {
    const y = i * 512 + 256;
    ctx.fillText(String(i), 256, y);
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.ClampToEdgeWrapping;
  texture.wrapT = THREE.ClampToEdgeWrapping;
  texture.repeat.set(1, 1 / 10);
  return texture;
}

interface DigitBoxProps {
  index: number;
  targetDigit: number;
  delay: number;
  isAnimating: boolean;
}

function DigitBox({ index, targetDigit, delay, isAnimating }: DigitBoxProps) {
  const meshRef = useRef<THREE.Mesh>(null);
  const texture = useMemo(() => createDigitTexture(), []);
  const currentY = useRef(0);
  const scrambleOffset = useRef(0);

  const material = useMemo(() => {
    return new THREE.MeshBasicMaterial({
      map: texture,
      side: THREE.FrontSide,
    });
  }, [texture]);

  useEffect(() => {
    if (!isAnimating) return;

    // Scramble animation
    const scrambleTl = gsap.timeline({ delay });
    
    // Rapid cycling
    scrambleTl.to(scrambleOffset, {
      current: 10,
      duration: 0.8,
      ease: 'steps(10)',
      onUpdate: () => {
        const cycle = Math.floor(scrambleOffset.current) % 10;
        texture.offset.y = cycle / 10;
      },
    });

    // Settle on target
    scrambleTl.to(currentY, {
      current: targetDigit,
      duration: 0.6,
      ease: 'expo.out',
      onUpdate: () => {
        texture.offset.y = currentY.current / 10;
      },
    });

    return () => {
      scrambleTl.kill();
    };
  }, [isAnimating, targetDigit, delay, texture]);

  useFrame(() => {
    if (meshRef.current) {
      // Subtle idle animation
      if (!isAnimating) {
        texture.offset.y = targetDigit / 10;
      }
    }
  });

  const xPos = (index - (DIGIT_COUNT - 1) / 2) * (DIGIT_WIDTH + SPACING);

  return (
    <mesh ref={meshRef} position={[xPos, 0, 0]} material={material}>
      <boxGeometry args={[DIGIT_WIDTH, DIGIT_HEIGHT, DIGIT_DEPTH]} />
    </mesh>
  );
}

function OdometerScene({ isAnimating }: { isAnimating: boolean }) {
  const targets = [0, 0, 1, 0, 1]; // "00101"
  const delays = [0, 0.1, 0.2, 0.3, 0.4];

  return (
    <>
      <ambientLight intensity={1} />
      {targets.map((target, i) => (
        <DigitBox
          key={i}
          index={i}
          targetDigit={target}
          delay={delays[i]}
          isAnimating={isAnimating}
        />
      ))}
    </>
  );
}

export default function GothicOdometer() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [isAnimating, setIsAnimating] = useState(false);

  useEffect(() => {
    if (!containerRef.current) return;

    const trigger = ScrollTrigger.create({
      trigger: containerRef.current,
      start: 'top 80%',
      end: 'bottom 20%',
      onEnter: () => setIsAnimating(true),
      onEnterBack: () => setIsAnimating(true),
    });

    return () => {
      trigger.kill();
    };
  }, []);

  return (
    <div ref={containerRef} style={{ width: '100%', height: '100%' }}>
      <Canvas
        camera={{ position: [0, 0, 8], fov: 50 }}
        style={{ background: 'transparent' }}
        gl={{ antialias: true, alpha: true }}
      >
        <OdometerScene isAnimating={isAnimating} />
      </Canvas>
    </div>
  );
}
