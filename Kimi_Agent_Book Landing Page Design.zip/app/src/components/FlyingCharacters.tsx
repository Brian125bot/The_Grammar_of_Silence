import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

interface FlyingCharactersProps {
  text: string;
  className?: string;
}

export default function FlyingCharacters({ text, className = '' }: FlyingCharactersProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const hasAnimated = useRef(false);

  useEffect(() => {
    if (!containerRef.current || hasAnimated.current) return;
    hasAnimated.current = true;

    const chars = containerRef.current.querySelectorAll<HTMLSpanElement>('.fly-char');

    // Set initial state - slightly twisted and pushed back
    gsap.set(chars, {
      rotationX: 15,
      rotationY: -8,
      z: -200,
      opacity: 0.6,
      filter: 'blur(2px)',
    });

    // Animate to flat on load
    gsap.to(chars, {
      rotationX: 0,
      rotationY: 0,
      z: 0,
      opacity: 1,
      filter: 'blur(0px)',
      duration: 1.2,
      ease: 'expo.out',
      stagger: {
        amount: 0.3,
        from: 'start',
      },
    });

    // Scroll-driven exit animation
    gsap.to(chars, {
      scrollTrigger: {
        trigger: containerRef.current.closest('#hero'),
        start: 'top top',
        end: 'bottom top',
        scrub: 1.5,
      },
      rotationX: 90,
      rotationY: 15,
      z: -800,
      opacity: 0,
      filter: 'blur(12px)',
      ease: 'power2.in',
      stagger: {
        amount: 0.2,
        from: 'start',
      },
    });

    return () => {
      ScrollTrigger.getAll().forEach(st => {
        if (st.vars.trigger === containerRef.current?.closest('#hero')) {
          st.kill();
        }
      });
    };
  }, []);

  // Split text into words, then characters
  const words = text.split(' ');

  return (
    <div
      ref={containerRef}
      className={`${className}`}
      style={{ perspective: '1000px', transformStyle: 'preserve-3d' }}
    >
      {words.map((word, wordIndex) => (
        <span key={wordIndex} className="inline-block" style={{ transformStyle: 'preserve-3d' }}>
          {word.split('').map((char, charIndex) => (
            <span
              key={`${wordIndex}-${charIndex}`}
              className="fly-char inline-block"
              style={{
                display: 'inline-block',
                willChange: 'transform, filter',
                transformStyle: 'preserve-3d',
              }}
            >
              {char}
            </span>
          ))}
          {wordIndex < words.length - 1 && (
            <span className="fly-char inline-block">&nbsp;</span>
          )}
        </span>
      ))}
    </div>
  );
}
