import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const chapters = [
  'The Use of High Register Language in Clerical Culture',
  'The Passive Voice as Moral Laundry',
  'Nominalization: Turning Verbs into Objects',
  'Epistemic Hedging and Modal Distancing',
  'Elevation Through Abstraction',
  'The Development of Vaticanesse',
  'Semantic Bleaching Through Ritual Repetition',
  'The Professionalization Trap',
  'Hierarchical Amplification',
];

const themes = [
  {
    title: 'Accompaniment',
    desc: 'A bureaucratic ritual of proximity without protection.',
  },
  {
    title: 'Healing',
    desc: 'Reframing institutional convenience as pastoral care.',
  },
  {
    title: 'Encounter',
    desc: 'The illusion of dialogue where power is preserved.',
  },
  {
    title: 'Integral',
    desc: 'A syntactic instrument for absorption and control.',
  },
];

export default function StackingCards() {
  const wrapperRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    if (!wrapperRef.current) return;

    const cards = cardsRef.current.filter(Boolean) as HTMLDivElement[];

    // Entrance animation for each card
    cards.forEach((card, i) => {
      if (i === 0) {
        // First card is visible by default, just add subtle entrance
        gsap.fromTo(
          card,
          { opacity: 0.8 },
          {
            opacity: 1,
            scrollTrigger: {
              trigger: card,
              start: 'top 90%',
              end: 'top 50%',
              scrub: true,
            },
          }
        );
        return;
      }

      gsap.fromTo(
        card,
        { y: '100vh', scale: 0.95 },
        {
          y: 0,
          scale: 1,
          scrollTrigger: {
            trigger: card,
            start: 'top bottom',
            end: 'top top',
            scrub: true,
          },
        }
      );
    });

    return () => {
      ScrollTrigger.getAll().forEach(st => st.kill());
    };
  }, []);

  const openBook = () => {
    window.open(
      'https://docs.google.com/document/d/1B7bi1h2z-dR12JzJKbYOXGDUyRLjoRHT/edit?usp=drivesdk&ouid=103249518831320869277&rtpof=true&sd=true',
      '_blank'
    );
  };

  return (
    <div
      id="stacking-cards"
      ref={wrapperRef}
      className="relative"
      style={{ height: '400vh' }}
    >
      {/* Card 1 - Table of Contents */}
      <div
        ref={el => { cardsRef.current[0] = el; }}
        className="sticky top-0 w-full min-h-[100dvh] flex flex-col justify-center px-6 md:px-10 lg:px-16 py-20"
        style={{ backgroundColor: '#F4F4F0', zIndex: 1 }}
      >
        <div className="max-w-6xl mx-auto w-full">
          <span
            className="font-mono text-[11px] mb-8 block"
            style={{ color: '#D91D1D', letterSpacing: '0.05em' }}
          >
            02. THE CONTENTS
          </span>
          <h2 className="font-display text-[8vw] md:text-[6vw] leading-[0.95] mb-12 md:mb-16" style={{ color: '#050505' }}>
            TABLE OF
            <br />
            CONTENTS
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-16 gap-y-3 md:gap-y-4">
            {chapters.map((chapter, i) => (
              <div
                key={i}
                className="flex items-baseline gap-4 py-2 md:py-3"
                style={{ borderBottom: '1px solid rgba(5, 5, 5, 0.1)' }}
              >
                <span
                  className="font-mono text-[10px] shrink-0"
                  style={{ color: 'rgba(5, 5, 5, 0.3)', letterSpacing: '0.05em' }}
                >
                  {String(i + 1).padStart(2, '0')}
                </span>
                <span className="font-body text-base md:text-xl leading-snug" style={{ color: '#050505' }}>
                  {chapter}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Card 2 - Key Themes */}
      <div
        ref={el => { cardsRef.current[1] = el; }}
        className="sticky top-0 w-full min-h-[100dvh] flex flex-col justify-center px-6 md:px-10 lg:px-16 py-20"
        style={{ backgroundColor: '#E8E8E4', zIndex: 2 }}
      >
        <div className="max-w-6xl mx-auto w-full">
          <span
            className="font-mono text-[11px] mb-8 block"
            style={{ color: '#D91D1D', letterSpacing: '0.05em' }}
          >
            03. THE VOCABULARY
          </span>
          <h2 className="font-display text-[8vw] md:text-[6vw] leading-[0.95] mb-12 md:mb-16" style={{ color: '#050505' }}>
            DISSECTING
            <br />
            THE VOCABULARY
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8">
            {themes.map((theme, i) => (
              <div
                key={i}
                className="p-6 md:p-8"
                style={{ border: '1px solid rgba(5, 5, 5, 0.1)' }}
              >
                <h3 className="font-display text-xl md:text-2xl mb-3" style={{ color: '#050505' }}>
                  {theme.title}
                </h3>
                <p
                  className="font-body text-sm md:text-base leading-relaxed"
                  style={{ color: 'rgba(5, 5, 5, 0.6)' }}
                >
                  {theme.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Card 3 - The Author */}
      <div
        ref={el => { cardsRef.current[2] = el; }}
        className="sticky top-0 w-full min-h-[100dvh] flex flex-col justify-center px-6 md:px-10 lg:px-16 py-20"
        style={{ backgroundColor: '#DCDCD6', zIndex: 3 }}
      >
        <div className="max-w-4xl mx-auto w-full text-center">
          <span
            className="font-mono text-[11px] mb-8 block"
            style={{ color: '#D91D1D', letterSpacing: '0.05em' }}
          >
            04. THE AUTHOR
          </span>
          <h2 className="font-display text-[10vw] md:text-[6vw] leading-[0.95] mb-8 md:mb-12" style={{ color: '#050505' }}>
            BRIAN
            <br />
            LAPOSA
          </h2>
          <p
            className="font-body text-lg md:text-2xl leading-relaxed max-w-2xl mx-auto mb-10 md:mb-14"
            style={{ color: 'rgba(5, 5, 5, 0.6)' }}
          >
            A critical examination of the language that shapes the faithful. Laposa dissects 
            the clerical lexicon to reveal the machinery of power hidden beneath the surface 
            of pastoral care.
          </p>
          <button
            onClick={openBook}
            className="font-mono text-[11px] md:text-xs px-8 py-4 cursor-pointer transition-all duration-300 hover:opacity-80"
            style={{
              backgroundColor: '#050505',
              color: '#FFFFFF',
              letterSpacing: '0.05em',
              border: 'none',
            }}
          >
            READ THE BOOK
          </button>
        </div>
      </div>
    </div>
  );
}
