export default function Footer() {
  const openBook = () => {
    window.open(
      'https://docs.google.com/document/d/1B7bi1h2z-dR12JzJKbYOXGDUyRLjoRHT/edit?usp=drivesdk&ouid=103249518831320869277&rtpof=true&sd=true',
      '_blank'
    );
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer
      className="relative w-full overflow-hidden"
      style={{
        backgroundColor: '#050505',
        borderTop: '1px solid rgba(255, 255, 255, 0.1)',
      }}
    >
      {/* Background text */}
      <div className="w-full overflow-hidden py-8 md:py-12">
        <h2
          className="font-display text-[12vw] md:text-[15vw] leading-[0.85] text-center whitespace-nowrap select-none"
          style={{ color: 'rgba(255, 255, 255, 0.05)' }}
        >
          THE GRAMMAR OF SILENCE
        </h2>
      </div>

      {/* Bottom links */}
      <div className="flex flex-col md:flex-row justify-between items-center px-6 md:px-10 py-6 md:py-8 gap-4 md:gap-0">
        <div className="flex flex-wrap justify-center md:justify-start gap-6 md:gap-10">
          <button
            onClick={openBook}
            className="font-mono text-[10px] md:text-[11px] text-white hover:text-[#D91D1D] transition-colors duration-300 cursor-pointer bg-transparent border-none"
            style={{ letterSpacing: '0.05em' }}
          >
            GOOGLE DOC
          </button>
          <button
            onClick={scrollToTop}
            className="font-mono text-[10px] md:text-[11px] text-white hover:text-[#D91D1D] transition-colors duration-300 cursor-pointer bg-transparent border-none"
            style={{ letterSpacing: '0.05em' }}
          >
            ABOUT THE AUTHOR
          </button>
          <button
            onClick={openBook}
            className="font-mono text-[10px] md:text-[11px] text-white hover:text-[#D91D1D] transition-colors duration-300 cursor-pointer bg-transparent border-none"
            style={{ letterSpacing: '0.05em' }}
          >
            PURCHASE
          </button>
        </div>
        <span
          className="font-mono text-[10px] text-white/30"
          style={{ letterSpacing: '0.05em' }}
        >
          &copy; 2026 BRIAN LAPOSA
        </span>
      </div>
    </footer>
  );
}
