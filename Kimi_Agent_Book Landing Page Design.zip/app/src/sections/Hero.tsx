import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import FlyingCharacters from '../components/FlyingCharacters';

gsap.registerPlugin(ScrollTrigger);

export default function Hero() {
  const heroRef = useRef<HTMLElement>(null);
  const bottomBarRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!heroRef.current || !bottomBarRef.current) return;

    // Fade out bottom bar on scroll
    gsap.to(bottomBarRef.current, {
      scrollTrigger: {
        trigger: heroRef.current,
        start: 'top top',
        end: '30% top',
        scrub: 1,
      },
      opacity: 0,
      y: 20,
    });

    return () => {
      ScrollTrigger.getAll().forEach(st => st.kill());
    };
  }, []);

  const scrollToOdometer = () => {
    const odometerSection = document.getElementById('odometer-section');
    if (odometerSection) {
      odometerSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToContents = () => {
    const contentsSection = document.getElementById('stacking-cards');
    if (contentsSection) {
      contentsSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="hero"
      ref={heroRef}
      className="relative w-full min-h-[100dvh] flex flex-col justify-between overflow-hidden"
      style={{ backgroundColor: '#050505' }}
    >
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 flex justify-between items-center px-6 md:px-10 py-5">
        <span
          className="font-mono text-white text-[11px] md:text-xs tracking-widest"
          style={{ letterSpacing: '0.05em' }}
        >
          BRIAN LAPOSA
        </span>
        <button
          onClick={scrollToContents}
          className="font-mono text-white text-[11px] md:text-xs tracking-widest hover:text-[#D91D1D] transition-colors duration-300 cursor-pointer bg-transparent border-none"
          style={{ letterSpacing: '0.05em' }}
        >
          CONTENTS
        </button>
      </nav>

      {/* Main Title */}
      <div className="flex-1 flex items-center justify-center px-4 md:px-10 pt-20 pb-10">
        <div className="text-center" style={{ perspective: '1000px', transformStyle: 'preserve-3d' }}>
          <FlyingCharacters
            text="THE GRAMMAR"
            className="font-display text-[12vw] md:text-[11vw] leading-[0.9] text-white font-medium"
          />
          <FlyingCharacters
            text="OF SILENCE"
            className="font-display text-[12vw] md:text-[11vw] leading-[0.9] text-white font-medium"
          />
        </div>
      </div>

      {/* Bottom Bar */}
      <div
        ref={bottomBarRef}
        className="flex justify-between items-end px-6 md:px-10 pb-6 md:pb-8"
      >
        <div className="font-mono text-[10px] md:text-[11px] text-white/50 max-w-[280px] md:max-w-none leading-relaxed"
          style={{ letterSpacing: '0.05em' }}
        >
          ECCLESIOLATRY IN THE ROMAN CATHOLIC CHURCH / 2026 EDITION
        </div>
        <button
          onClick={scrollToOdometer}
          className="w-10 h-10 border border-white/30 flex items-center justify-center hover:bg-white hover:border-white transition-all duration-300 group cursor-pointer bg-transparent shrink-0 ml-4"
          aria-label="Explore"
        >
          <svg
            width="14"
            height="14"
            viewBox="0 0 14 14"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="stroke-white group-hover:stroke-[#050505] transition-colors duration-300"
          >
            <line x1="7" y1="1" x2="7" y2="13" strokeWidth="1" />
            <line x1="1" y1="7" x2="13" y2="7" strokeWidth="1" />
          </svg>
        </button>
      </div>
    </section>
  );
}
