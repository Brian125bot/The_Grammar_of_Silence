import { useEffect, useRef, Suspense, lazy } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const GothicOdometer = lazy(() => import('../components/GothicOdometer'));

export default function OdometerSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const textRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!sectionRef.current || !textRef.current) return;

    gsap.fromTo(
      textRef.current.children,
      { y: 60, opacity: 0 },
      {
        y: 0,
        opacity: 1,
        duration: 1,
        ease: 'expo.out',
        stagger: 0.15,
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top 60%',
          toggleActions: 'play none none reverse',
        },
      }
    );

    return () => {
      ScrollTrigger.getAll().forEach(st => st.kill());
    };
  }, []);

  return (
    <section
      id="odometer-section"
      ref={sectionRef}
      className="relative w-full min-h-[80vh] flex flex-col md:flex-row"
      style={{
        backgroundColor: '#050505',
        borderTop: '1px solid rgba(255, 255, 255, 0.1)',
      }}
    >
      {/* Left Column - Text */}
      <div
        ref={textRef}
        className="w-full md:w-[35%] lg:w-[30%] flex flex-col justify-center px-6 md:px-10 lg:px-16 py-16 md:py-0"
      >
        <span
          className="font-mono text-[11px] mb-6"
          style={{ color: '#D91D1D', letterSpacing: '0.05em' }}
        >
          01. THE INSTITUTION
        </span>
        <h2 className="font-display text-[8vw] md:text-[3vw] text-white leading-[1] mb-8">
          MEASURING
          <br />
          THE VOID
        </h2>
        <p
          className="font-body text-base md:text-lg leading-relaxed max-w-md"
          style={{ color: 'rgba(255, 255, 255, 0.5)' }}
        >
          An exploration of how the modern Church quantifies faith, administers grace, 
          and leaves the faithful in a state of perpetual suspension. The language of 
          institution creates silence where there should be voice.
        </p>
      </div>

      {/* Right Column - 3D Odometer */}
      <div className="w-full md:w-[65%] lg:w-[70%] h-[50vh] md:h-auto relative">
        <Suspense
          fallback={
            <div className="w-full h-full flex items-center justify-center">
              <div
                className="font-display text-[15vw] md:text-[10vw] font-medium"
                style={{ color: '#D91D1D' }}
              >
                00101
              </div>
            </div>
          }
        >
          <GothicOdometer />
        </Suspense>
      </div>
    </section>
  );
}
